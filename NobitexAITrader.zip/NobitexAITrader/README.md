# Nobitex AI Trader — Android MVP
این پروژه اسکلت اجرایی نسخه اول ربات معاملات کوتاه‌مدت نوبیتکس است.

## در این نسخه
- دریافت واقعی Order Book از API نوبیتکس برای BTCIRT
- موتور تحلیل پایه و قابل تعویض با AI واقعی
- Risk Engine اولیه
- ساختار Paper/Live
- ذخیره امن Token با EncryptedSharedPreferences
- **هیچ قابلیت برداشت/انتقال دارایی ندارد**

## درباره Live Trading
مستندات رسمی نوبیتکس API امکان معامله خودکار و محیط Testnet را اعلام می‌کنند. برای جلوگیری از قرار گرفتن کلید در سورس، توکن واقعی داخل پروژه نیست. سفارش واقعی باید پس از تکمیل BiometricPrompt، Pre-Trade Checklist، Duplicate Protection، Recovery، TP/SL و تست Testnet فعال شود.

مستندات رسمی: https://apidocs.nobitex.ir/
Testnet: https://testnet.nobitex.ir/ و https://testnetapi.nobitex.ir/

## قابلیت‌های برنامه کامل
AI strategy selection, High-Confidence Mode, Smart Entry, Multi-AI Confirmation, Market Regime, Adaptive Strategy, Strategy Tournament, Shadow AI, Backtest, Paper Trading, Walk-Forward Learning, Dynamic Risk, Drawdown Protection, Circuit Breaker, Profit Lock, Trailing Stop, fee/slippage guard, data-quality guard, latency guard, recovery, audit log, AI versioning, gradual capital scaling, explainable AI و pre-trade checklist.
