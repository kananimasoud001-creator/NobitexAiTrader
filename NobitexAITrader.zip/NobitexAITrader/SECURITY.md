# Security
- No withdrawals or asset transfers.
- Never hard-code API tokens/private keys.
- Live orders must pass risk and safety gates.
- Use a least-privilege API credential and Testnet first.
