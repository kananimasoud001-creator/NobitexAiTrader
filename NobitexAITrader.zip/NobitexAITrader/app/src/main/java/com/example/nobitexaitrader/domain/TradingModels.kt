package com.example.nobitexaitrader.domain
data class Signal(val side:String,val strategy:String,val confidence:Int,val entry:Double,val stop:Double,val takeProfit:Double,val reason:String,val valid:Boolean)
data class RiskConfig(val riskPercent:Double=1.0,val dailyLossPercent:Double=2.0,val maxTrades:Int=3)
enum class TradingMode{PAPER,LIVE}
