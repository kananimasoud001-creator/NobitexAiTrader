package com.example.nobitexaitrader
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.nobitexaitrader.ui.MainViewModel
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
@Composable fun App(vm:MainViewModel=viewModel()){val price by vm.price.collectAsState();val signal by vm.signal.collectAsState();val status by vm.status.collectAsState();MaterialTheme{Surface(Modifier.fillMaxSize()){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text("Nobitex AI Trader",style=MaterialTheme.typography.headlineMedium);Text("ربات معاملات کوتاه‌مدت — MVP");Card{Column(Modifier.padding(16.dp)){Text("BTC/IRT");Text("قیمت: $price")}};Card{Column(Modifier.padding(16.dp)){Text("AI Signal",style=MaterialTheme.typography.titleLarge);Text(signal?.let{"${it.side} | ${it.strategy} | Confidence ${it.confidence}/100"}?:"هنوز تحلیلی انجام نشده");signal?.let{Text("Entry: ${it.entry}\nSL: ${it.stop}\nTP: ${it.takeProfit}\n${it.reason}")}}};Text(status);Button(onClick={vm.refresh()}){Text("تحلیل بازار")};Text("Live Trading بعد از تست‌نت و فعال‌سازی امن تکمیل می‌شود.",style=MaterialTheme.typography.bodySmall);Text("برداشت و انتقال دارایی در این اپ وجود ندارد.",style=MaterialTheme.typography.bodySmall)}}}}
