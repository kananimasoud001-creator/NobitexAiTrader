package com.example.nobitexaitrader.data
import kotlinx.serialization.Serializable
import retrofit2.http.*
@Serializable data class OrderBook(val status:String,val lastTradePrice:String?=null,val bids:List<List<String>>=emptyList(),val asks:List<List<String>>=emptyList())
@Serializable data class AddOrderRequest(val type:String,val srcCurrency:String,val dstCurrency:String,val amount:String,val price:String?=null,val mode:String="cross",val clientOrderId:String?=null)
@Serializable data class AddOrderResponse(val status:String,val code:String?=null,val message:String?=null,val id:Long?=null,val clientOrderId:String?=null)
interface NobitexApi { @GET("v3/orderbook/{symbol}") suspend fun orderBook(@Path("symbol") symbol:String):OrderBook; @POST("market/orders/add") suspend fun addOrder(@Header("Authorization") token:String,@Body body:AddOrderRequest):AddOrderResponse }
