package com.example.nobitexaitrader.security
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
class SecretStore(context:Context){private val master=MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build();private val prefs=EncryptedSharedPreferences.create(context,"secure_secrets",master,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);fun putToken(t:String)=prefs.edit().putString("nobitex_token",t).apply();fun token():String?=prefs.getString("nobitex_token",null);fun clear()=prefs.edit().clear().apply()}
