package com.example.nobitexaitrader.ui
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.nobitexaitrader.data.NobitexClient
import com.example.nobitexaitrader.domain.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
class MainViewModel:ViewModel(){private val _price=MutableStateFlow("—");val price=_price.asStateFlow();private val _signal=MutableStateFlow<Signal?>(null);val signal=_signal.asStateFlow();private val _status=MutableStateFlow("در حال آماده‌سازی");val status=_status.asStateFlow();private val ai=AiEngine();fun refresh()=viewModelScope.launch{try{val ob=NobitexClient.api.orderBook("BTCIRT");val p=ob.lastTradePrice?.toDoubleOrNull()?:ob.bids.firstOrNull()?.firstOrNull()?.toDoubleOrNull()?:0.0;_price.value=p.toString();val prev=ob.bids.getOrNull(1)?.firstOrNull()?.toDoubleOrNull()?:p;val high=ob.asks.maxOfOrNull{it.firstOrNull()?.toDoubleOrNull()?:p}?:p;val low=ob.bids.minOfOrNull{it.firstOrNull()?.toDoubleOrNull()?:p}?:p;_signal.value=ai.analyze(p,prev,high,low);_status.value="داده بازار دریافت شد — Paper Trading"}catch(e:Exception){_status.value="خطا: ${e.message?:"unknown"}"}}}
