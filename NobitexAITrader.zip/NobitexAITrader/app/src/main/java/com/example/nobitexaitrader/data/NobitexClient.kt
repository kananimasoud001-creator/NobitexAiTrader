package com.example.nobitexaitrader.data
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import com.jakewharton.retrofit2.converter.kotlinx.serialization.asConverterFactory
import okhttp3.MediaType.Companion.toMediaType
object NobitexClient { private val json=Json{ignoreUnknownKeys=true}; private val http=OkHttpClient.Builder().retryOnConnectionFailure(true).build(); val api:NobitexApi=Retrofit.Builder().baseUrl("https://api.nobitex.ir/").client(http).addConverterFactory(json.asConverterFactory("application/json".toMediaType())).build().create(NobitexApi::class.java) }
