plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("org.jetbrains.kotlin.plugin.serialization") }
android { namespace = "com.example.nobitexaitrader"; compileSdk = 35
 defaultConfig { applicationId = "com.example.nobitexaitrader"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0"); implementation("androidx.activity:activity-compose:1.10.0")
 implementation("androidx.compose.ui:ui:1.7.8"); implementation("androidx.compose.material3:material3:1.3.1"); implementation("androidx.compose.ui:ui-tooling-preview:1.7.8"); debugImplementation("androidx.compose.ui:ui-tooling:1.7.8")
 implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7"); implementation("androidx.security:security-crypto:1.1.0-alpha06")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0"); implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
 implementation("com.squareup.okhttp3:okhttp:4.12.0"); implementation("com.squareup.retrofit2:retrofit:2.11.0"); implementation("com.jakewharton.retrofit:retrofit2-kotlinx-serialization-converter:1.0.0")
}
